﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace High_or_Low
{
    class Program
    {
        static void Main(string[] args)
        {
        


            // Display a welcome message
            Console.WriteLine("Welcome to the High or Low Game!");

            // Generates a random number
            Random rng = new Random();
            int number = rng.Next(1, 10);

            int tries = 0;

            while (true)
            {

                // User enters their guess
                Console.Write("Enter a guess: ");
                int guess = Convert.ToInt32(Console.ReadLine());

                // Compare guess to number and guesses the amount of tries
                if (guess < number)
                {
                    Console.WriteLine("Too low.");
                    tries += 1;
                }
                else if (guess > number)
                {
                    Console.WriteLine("Too high.");
                    tries += 1;
                }
                else
                {
                    Console.WriteLine("Your guess is correct.");
                    tries += 1;
                    Console.WriteLine("It took you" + tries, " tries");
                    break;
                }
            }

            {



                // Wait until key is pressed
                Console.ReadKey();



            }
        }
    }
}

    

